$('#button_publish').click(function(){
    setTimeout(function(){
        alert("发布成功");
        document.getElementById("number1").innerText = "数字逻辑实验";
        document.getElementById("number2").innerText = "665354";
        document.getElementById("number3").innerText = "02";
        document.getElementById("number4").innerText = "江安实验室二基楼B301";
        document.getElementById("number5").innerText = "6月23号 9:00 - 12:00";
        document.getElementById("number6").innerText = "陈泽源";
        document.getElementById("test_name").setAttribute("placeholder","数字逻辑实验期末考试");
        document.getElementById("course_name").setAttribute("placeholder","数字逻辑实验");
        document.getElementById("course_id").setAttribute("placeholder","665354");
        document.getElementById("test_time").setAttribute("placeholder","6月23号 9:00 - 12:00");
        document.getElementById("test_place").setAttribute("placeholder","江安实验室二基楼B301");
        document.getElementById("teacher").setAttribute("placeholder","陈泽源");
        
    
    },10);

 
});
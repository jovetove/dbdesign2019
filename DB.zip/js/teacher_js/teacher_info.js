$('#teacher_button_find').click(function(){
    setTimeout(function(){
        alert("信息查询成功");
        document.getElementById("teacher_department").innerText = "软件学院";
    document.getElementById("teacher_phone").innerText = "18368171073";
    document.getElementById("teacher_qq").innerText = "1063356646";
    document.getElementById("teacher_email").innerText = "1063356646@qq.com";
    document.getElementById("teacher_degree").innerText = "硕士";
    document.getElementById("teacher_position").innerText = "讲师";
    document.getElementById("teacher_name").innerText = "陈泽源";
    document.getElementById("teacher_gender").innerText = "男";
    document.getElementById("teacher_id").innerText = "2017141471239";
    document.getElementById("teacher_adress").innerText = "成都市双流区江安花园xxx室";
    document.getElementById("input_name").setAttribute("placeholder","陈泽源");
    document.getElementById("input_id").setAttribute("placeholder","2017141471239");
    },10);
 
});
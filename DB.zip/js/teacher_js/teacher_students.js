$('#page_2').click(function(){
    setTimeout(function(){
        alert("跳转成功");
        document.getElementById("1_1").innerText = "程序设计基础";
        document.getElementById("1_2").innerText = "314425";
        document.getElementById("1_3").innerText = "03";
        document.getElementById("1_4").innerText = "软件学院";
        document.getElementById("1_5").innerText = "4";
        document.getElementById("2_1").innerText = "计算机系统导论";
        document.getElementById("2_2").innerText = "314456";
        document.getElementById("2_3").innerText = "02";
        document.getElementById("2_4").innerText = "软件学院";
        document.getElementById("2_5").innerText = "3";
        document.getElementById("3_1").innerText = "新生专业研讨课";
        document.getElementById("3_2").innerText = "315585";
        document.getElementById("3_3").innerText = "02";
        document.getElementById("3_4").innerText = "软件学院";
        document.getElementById("3_5").innerText = "2";
        document.getElementById("4_1").innerText = "数据结构与算法";
        document.getElementById("4_2").innerText = "318854";
        document.getElementById("4_3").innerText = "01";
        document.getElementById("4_4").innerText = "软件学院";
        document.getElementById("4_5").innerText = "4";
        document.getElementById("5_1").innerText = "编译原理";
        document.getElementById("5_2").innerText = "311004";
        document.getElementById("5_3").innerText = "01";
        document.getElementById("5_4").innerText = "计算机学院";
        document.getElementById("5_5").innerText = "3";
        document.getElementById("6_1").innerText = "软件需求分析";
        document.getElementById("6_2").innerText = "311034";
        document.getElementById("6_3").innerText = "01";
        document.getElementById("6_4").innerText = "软件学院";
        document.getElementById("6_5").innerText = "3";
        document.getElementById("7_1").innerText = "人机交互概论";
        document.getElementById("7_2").innerText = "311089";
        document.getElementById("7_3").innerText = "03";
        document.getElementById("7_4").innerText = "软件学院";
        document.getElementById("7_5").innerText = "3";
        document.getElementById("page_2_item").setAttribute("class","page-item active");
        document.getElementById("page_1_item").setAttribute("class","page-item");
    },3000);

 
});



$('#page_next').click(function(){
    setTimeout(function(){
        alert("跳转成功");
        document.getElementById("1_1").innerText = "程序设计基础";
        document.getElementById("1_2").innerText = "314425";
        document.getElementById("1_3").innerText = "03";
        document.getElementById("1_4").innerText = "软件学院";
        document.getElementById("1_5").innerText = "4";
        document.getElementById("2_1").innerText = "计算机系统导论";
        document.getElementById("2_2").innerText = "314456";
        document.getElementById("2_3").innerText = "02";
        document.getElementById("2_4").innerText = "软件学院";
        document.getElementById("2_5").innerText = "3";
        document.getElementById("3_1").innerText = "新生专业研讨课";
        document.getElementById("3_2").innerText = "315585";
        document.getElementById("3_3").innerText = "02";
        document.getElementById("3_4").innerText = "软件学院";
        document.getElementById("3_5").innerText = "2";
        document.getElementById("4_1").innerText = "数据结构与算法";
        document.getElementById("4_2").innerText = "318854";
        document.getElementById("4_3").innerText = "01";
        document.getElementById("4_4").innerText = "软件学院";
        document.getElementById("4_5").innerText = "4";
        document.getElementById("5_1").innerText = "编译原理";
        document.getElementById("5_2").innerText = "311004";
        document.getElementById("5_3").innerText = "01";
        document.getElementById("5_4").innerText = "计算机学院";
        document.getElementById("5_5").innerText = "3";
        document.getElementById("6_1").innerText = "软件需求分析";
        document.getElementById("6_2").innerText = "311034";
        document.getElementById("6_3").innerText = "01";
        document.getElementById("6_4").innerText = "软件学院";
        document.getElementById("6_5").innerText = "3";
        document.getElementById("7_1").innerText = "人机交互概论";
        document.getElementById("7_2").innerText = "311089";
        document.getElementById("7_3").innerText = "03";
        document.getElementById("7_4").innerText = "软件学院";
        document.getElementById("7_5").innerText = "3";
        document.getElementById("page_2_item").setAttribute("class","page-item active");
        document.getElementById("page_1_item").setAttribute("class","page-item");
    },3000);

 
});
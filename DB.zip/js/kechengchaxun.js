function btnAction()
{
    alert("t1");
    var postData= {
        "param1": "param1",
        "areaId":2,
        "deleteId":3,
        "ids" : "254,249,248"
    }
    var num = 20170101001;
    var course_name = $('#type_course_name').val();
    var course_id = $('#course_id').val();
    var course_id2 = $('#course_id2').val();    
    var course_depart = $('#course_depart-select').serialize();
    var course_category = $('#course_category-select').serialize();
    var year_month = $('#year_month').serialize();
    alert("t2");
    $.ajax({
        async : false,
        cache : false,  //不使用当前浏览器的缓存
        type : 'POST',
        headers: {
            "cache-control": "no-cache",
            "postman-token": "da9ebbc0-3a39-2250-f0fa-ac42a5c305c1"
            },
        url : 'http://119.23.250.250/api',
        dataType : "json",
        data: JSON.stringify({"api_name": "stuinfo","params": {"stu_id":String(num)}, "fields":"ID,Name,Sex,Dept_name,Cred,GPA,Tel,E-mail"}),
        error : function() {
            alert('请求失败 ');
        },
        success : function(result){
            console.log(result);
            document.getElementById("result_course_searching").innerHTML = "学分：" + result.Cred + "<br>学院：" + result.Dept_name + "<br>GPA：" + result.GPA;
        }
    });
}
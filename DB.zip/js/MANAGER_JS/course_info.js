$('#btn_course_find').click(function(){
    setTimeout(function(){
        alert("查询到课程信息");
        document.getElementById("table_search_result").style = "visibility:display";
    },2500);
});
$('#newCourseInfoUpload').click(function(){
    setTimeout(function(){
        alert("课程信息修改成功");
        document.getElementById("course_r_name").innerHTML = "风景园林艺术鉴赏";
    },2500);
});
$('#addStuInfoUpload').click(function(){
    setTimeout(function(){
        alert('添加成功！');
    },2500);});
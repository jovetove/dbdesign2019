$('#button_infoChange').click(function(){
    // alert('信息更改功能的实现');
    // setTimeout(function(){alert("Hello")},1);
});

$('#changeUpload_chit').click(function(){
    setTimeout(function(){
        alert("信息修改成功");
        document.getElementById("manager_info_phoneNumber").innerHTML = "15130236789";
    },3000);
});

// window.onload = function(){
//     //获取按钮节点并添加点击事件
//     var myBtn = document.getElementById("changeUpload_chit");
//     btn.onclick = function (){
//         //定时器，一秒后触发
//         setTimeout(tip,"1000");
//     }
//     //事件函数
//     function tip(){
//         alert("是不是过了一秒？");
//     }
// }
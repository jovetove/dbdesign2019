$('#teacher_button_find').click(function(){
    setTimeout(function(){
        alert("获得查询结果！");
        //照片会报错
        // var img = document.getElementById('head_pic');
        // img.src = 'img/川.jpg';
        document.getElementById("teacher_info_name").innerHTML = "陈奕迅";
        document.getElementById("teacher_info_gender").innerHTML = "男";
        document.getElementById("teacher_info_id").innerHTML = "201714147001";
        document.getElementById("teacher_info_major").innerHTML = "歌唱";
        document.getElementById("teacher_info_entryYear").innerHTML = "2017";
        document.getElementById("teacher_info_department").innerHTML = "艺术学院";
        document.getElementById("teacher_info_phoneNumber").innerHTML = "15130447219";
        document.getElementById("teacher_info_address").innerHTML = "四川大学江安校区19舍";
    },2000);
});
$('#newUserInfoUpload').click(function(){
    setTimeout(function(){
        alert('新用户创建成功！');
    },2000);
});
$('#changeUpload').click(function(){
    alert('修改用户信息功能完成');
});
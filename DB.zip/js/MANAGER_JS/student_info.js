$('#stu_button_find').click(function(){
    setTimeout(function(){
        alert("获得查询结果！");
        //照片会报错
        // var img = document.getElementById('head_pic');
        // img.src = '../../img/川.jpg';
        document.getElementById("student_info_name").innerHTML = "周杰伦";
        document.getElementById("student_info_gender").innerHTML = "男";
        document.getElementById("student_info_id").innerHTML = "201714147000";
        document.getElementById("student_info_major").innerHTML = "计算机科学与技术";
        document.getElementById("student_info_entryYear").innerHTML = "2017";
        document.getElementById("student_info_department").innerHTML = "软件学院";
        document.getElementById("student_info_phoneNumber").innerHTML = "15130447217";
        document.getElementById("student_info_address").innerHTML = "四川大学江安校区22舍";
    },2000);

});
$('#newUserInfoUpload').click(function(){
    setTimeout(function(){
        alert('新用户创建成功');
    },2000)
});
$('#changeUpload').click(function(){
    setTimeout(function(){
        alert('成功修改用户信息！');
        document.getElementById("student_info_major").innerHTML = "软件工程";
    },2000)
});